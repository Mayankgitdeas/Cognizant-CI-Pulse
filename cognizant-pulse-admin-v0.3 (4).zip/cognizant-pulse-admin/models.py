"""
models.py — Data models

The Signal is the core entity. Notice the four `impact_*` fields — these
match the four template questions the analyst fills in. The frontend renders
them as a structured 4-bullet impact analysis.
"""

from datetime import datetime, timezone
from typing import Optional
from sqlmodel import SQLModel, Field, Column
from sqlalchemy import JSON


class Impact:
    HI = "hi"
    MED = "med"
    LO = "lo"


class SourceType:
    OFFICIAL = "official"
    FINANCIAL = "financial"
    MEDIA = "media"


class SignalStatus:
    """Whether a signal is a draft (analyst still reviewing) or published (live to users)."""
    DRAFT = "draft"
    PUBLISHED = "published"


# ─── THE SIGNAL ──────────────────────────────────────────────────────────────

class Signal(SQLModel, table=True):
    """One news item about a competitor, with a Cognizant impact analysis."""

    id: Optional[int] = Field(default=None, primary_key=True)

    # ─── Draft vs Published ───────────────────────────────────────────────
    # Drafts are pre-filled by the scraper; analyst reviews + adds impact
    # analysis before publishing. Public API only returns published signals.
    status: str = Field(default=SignalStatus.PUBLISHED, index=True)

    # ─── Article basics (filled by analyst or scraper) ────────────────────
    competitor: str = Field(index=True)
    headline: str
    description: str
    url: str = Field(unique=True)

    # ─── Classification (filled by analyst) ──────────────────────────────
    tags: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    topics: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    impact: str = Field(default=Impact.MED)  # hi | med | lo

    # ─── Source provenance (filled by analyst) ───────────────────────────
    source: str
    source_type: str = Field(default=SourceType.OFFICIAL)
    source_priority: int = Field(default=1)

    # ─── Timestamps ──────────────────────────────────────────────────────
    published_at: datetime = Field(index=True)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # ─── Impact analysis (the 4-question template the analyst fills) ─────
    # Stored as separate fields so the frontend can render them as
    # the standard 4-bullet layout consistently.
    impact_pipeline_risk: Optional[str] = Field(default=None)
    impact_verticals: Optional[str] = Field(default=None)
    impact_opportunity: Optional[str] = Field(default=None)
    impact_intel_gap: Optional[str] = Field(default=None)
    analyst_name: Optional[str] = Field(default=None)
