"""
database.py — Database connection and session management

SQLite locally, swap DATABASE_URL for PostgreSQL in production.
"""

import logging
from sqlmodel import SQLModel, create_engine, Session, text
from config import settings

log = logging.getLogger(__name__)


engine = create_engine(
    settings.database_url,
    echo=False,
    connect_args=(
        {"check_same_thread": False}
        if settings.database_url.startswith("sqlite")
        else {}
    ),
)


def init_db() -> None:
    """Create all tables defined in models.py if they don't already exist.

    Also runs simple migrations for added columns (since SQLModel.create_all
    only creates new tables, it doesn't ALTER existing ones).
    """
    SQLModel.metadata.create_all(engine)
    _migrate_add_status_column()


def _migrate_add_status_column() -> None:
    """Add the 'status' column to existing signal tables if missing.

    Used when upgrading an existing pulse.db that was created before the
    draft/published feature. New rows default to 'published'.
    """
    try:
        with engine.connect() as conn:
            # Check if 'status' column exists in the signal table
            result = conn.execute(text("PRAGMA table_info(signal)"))
            cols = [row[1] for row in result.fetchall()]
            if "status" not in cols:
                conn.execute(text(
                    "ALTER TABLE signal ADD COLUMN status VARCHAR DEFAULT 'published' NOT NULL"
                ))
                conn.commit()
                log.info("Migration: added 'status' column to signal table")
            else:
                log.debug("Migration: 'status' column already present")
    except Exception as e:
        # Non-fatal — if migration fails the app may still work for new installs
        log.warning(f"Status column migration check failed (may be normal on first run): {e}")


def get_session() -> Session:
    """Hand out a database session. Use as `with get_session() as s: ...`"""
    return Session(engine)
