"""
scraper.py — Competitor newsroom scrapers

Fetches recent articles from 5 P1 competitor newsrooms using a multi-strategy
approach: tries sitemap.xml first (works for JS-rendered SPA newsrooms),
falls back to HTML listing parse if sitemap fails.

LEGAL NOTE: Scraping public newsroom pages is a gray area. This implementation
is for INTERNAL Cognizant use only. Cognizant Legal should review before any
pilot rollout beyond your laptop.

Mitigation measures:
  - Triggered ONLY by admin click (no continuous crawling)
  - Single request per source per scrape
  - Identifying User-Agent
  - Captures only enough text to identify signals
"""

import asyncio
import logging
import re
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional
from urllib.parse import urljoin
import xml.etree.ElementTree as ET

import httpx
from bs4 import BeautifulSoup

log = logging.getLogger(__name__)

# ─── CONFIG ──────────────────────────────────────────────────────────────────

USER_AGENT = "Cognizant CI Pulse Bot (Internal Competitive Intelligence Tool)"
REQUEST_TIMEOUT = 25.0
MAX_ARTICLES_PER_SOURCE = 20  # accept up to 20 candidates from sitemap (we'll filter)
ARTICLE_FETCH_LIMIT = 15      # fetch up to 15 article pages for real date + metadata


# ─── DATA TYPES ──────────────────────────────────────────────────────────────

@dataclass
class ScrapedArticle:
    competitor: str
    url: str
    headline: str
    description: str
    published_at: datetime
    source: str
    source_priority: int = 1
    suggested_tag: Optional[str] = None
    suggested_topics: Optional[list] = None
    suggested_impact: str = "med"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["published_at"] = self.published_at.isoformat()
        return d


@dataclass
class ScrapeResult:
    articles: list
    failed_sources: list
    duration_seconds: float

    def to_dict(self) -> dict:
        return {
            "articles": [a.to_dict() for a in self.articles],
            "failed_sources": self.failed_sources,
            "count": len(self.articles),
            "duration_seconds": round(self.duration_seconds, 2),
        }


# ─── CLASSIFICATION HEURISTICS ───────────────────────────────────────────────

TAG_KEYWORDS = {
    "M&A":         ["acquisition", "acquires", "acquired", "merger", "acquires", "completed the acquisition", "to acquire"],
    "Partnership": ["partnership", "partners with", "alliance", "collaboration", "joint venture", "strategic agreement", "strategic collaboration"],
    "Contract":    ["wins", "deal", "selects", "selected to", "engagement", "transformation engagement", "secures"],
    "Leadership":  ["appoints", "names", "elects", "ceo", "cfo", "cto", "chief executive", "leadership change", "new leadership"],
    "Product":     ["launches", "unveils", "introduces", "announces availability", "release of", "new offering"],
}

TOPIC_KEYWORDS = {
    "AI & Gen AI":      ["ai", "artificial intelligence", "generative", "genai", "gen ai", "machine learning", "openai", "anthropic", "claude", "agentic", "llm"],
    "Cloud":            ["cloud", "azure", "aws", "amazon web services", "google cloud", "gcp"],
    "BFSI":             ["bank", "banking", "financial services", "insurance", "fintech", "capital markets", "wealth", "p&c"],
    "Healthcare":       ["healthcare", "health", "hospital", "patient", "clinical", "pharma", "biotech", "medical", "klas"],
    "Manufacturing":    ["manufacturing", "industrial", "factory", "supply chain", "agri", "food", "automotive", "aerospace", "siemens", "olam"],
    "Retail":           ["retail", "ecommerce", "e-commerce", "consumer goods", "cpg", "store", "shopper", "merchant"],
    "Data & Analytics": ["data platform", "data lake", "data warehouse", "analytics platform", "insights"],
    "GCC":              ["gcc", "global capability", "captive center"],
}

IMPACT_HIGH_KEYWORDS = [
    "billion", "$1b", "8-year", "10-year", "multi-year", "largest", "strategic transformation",
    "first-of-its-kind", "first of its kind", "industry first", "global partnership",
    "completes acquisition", "to acquire", "named partner of the year",
]
IMPACT_LOW_KEYWORDS = [
    "esop", "stock option", "share allotment", "annual report", "dividend",
    "board meeting", "investor presentation", "calendar",
]


def suggest_classification(headline: str, description: str) -> dict:
    text = (headline + " " + description).lower()
    tag = None
    for candidate, keywords in TAG_KEYWORDS.items():
        if any(kw in text for kw in keywords):
            tag = candidate
            break
    topics = [t for t, kws in TOPIC_KEYWORDS.items() if any(kw in text for kw in kws)]
    impact = "med"
    if any(kw in text for kw in IMPACT_HIGH_KEYWORDS):
        impact = "hi"
    elif any(kw in text for kw in IMPACT_LOW_KEYWORDS):
        impact = "lo"
    return {"tag": tag, "topics": topics, "impact": impact}


# ─── HTTP & PARSING HELPERS ──────────────────────────────────────────────────

async def fetch_text(url: str, client: httpx.AsyncClient) -> Optional[str]:
    """Fetch URL and return text. Returns None on failure."""
    try:
        response = await client.get(url, follow_redirects=True)
        response.raise_for_status()
        return response.text
    except Exception as e:
        log.warning(f"Failed to fetch {url}: {type(e).__name__}")
        return None


def parse_sitemap_xml(xml_text: str, url_pattern: re.Pattern, cutoff: datetime, upper: Optional[datetime] = None) -> list:
    """Parse a sitemap.xml string and return [(url, lastmod_datetime), ...]
    filtering by url_pattern (regex) and date range [cutoff, upper]."""
    results = []
    try:
        cleaned = re.sub(r'\sxmlns="[^"]+"', '', xml_text, count=1)
        root = ET.fromstring(cleaned)
    except ET.ParseError as e:
        log.warning(f"Sitemap XML parse error: {e}")
        return results

    for url_elem in root.findall(".//url"):
        loc = url_elem.findtext("loc", "").strip()
        lastmod_str = url_elem.findtext("lastmod", "").strip()
        if not loc or not url_pattern.search(loc):
            continue
        lastmod = None
        if lastmod_str:
            try:
                lastmod = datetime.fromisoformat(lastmod_str.replace("Z", "+00:00"))
                if lastmod.tzinfo is None:
                    lastmod = lastmod.replace(tzinfo=timezone.utc)
            except ValueError:
                try:
                    lastmod = datetime.strptime(lastmod_str[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
                except ValueError:
                    pass
        if lastmod and lastmod >= cutoff:
            if upper is None or lastmod <= upper:
                results.append((loc, lastmod))
    return results


def parse_sitemap_index(xml_text: str) -> list:
    """If the fetched sitemap is an index (<sitemapindex>), return list of child sitemap URLs."""
    try:
        cleaned = re.sub(r'\sxmlns="[^"]+"', '', xml_text, count=1)
        root = ET.fromstring(cleaned)
        if root.tag != "sitemapindex":
            return []
        return [sm.findtext("loc", "").strip() for sm in root.findall(".//sitemap") if sm.findtext("loc")]
    except ET.ParseError:
        return []


async def fetch_article_metadata(url: str, client: httpx.AsyncClient) -> Optional[dict]:
    """Fetch an article page and extract title, description, and real publish date.

    Returns {'title': str, 'description': str, 'published_at': datetime | None}.
    For published_at we try (in order):
      1. <meta property="article:published_time">
      2. <meta name="publish_date">, name="pubdate", name="date"
      3. <meta itemprop="datePublished">
      4. <time datetime="...">
      5. JSON-LD <script type="application/ld+json"> datePublished
      6. None (caller decides what to do)
    """
    html = await fetch_text(url, client)
    if not html:
        return None
    soup = BeautifulSoup(html, "html.parser")

    # Title — try og:title first, fall back to <title>
    title = ""
    og = soup.find("meta", property="og:title")
    if og and og.get("content"):
        title = og["content"].strip()
    elif soup.title:
        title = soup.title.get_text(strip=True)

    # Description
    desc = ""
    og_d = soup.find("meta", property="og:description")
    if og_d and og_d.get("content"):
        desc = og_d["content"].strip()
    else:
        meta_d = soup.find("meta", attrs={"name": "description"})
        if meta_d and meta_d.get("content"):
            desc = meta_d["content"].strip()

    # ── Real publish date — try multiple strategies ────────────────────────
    published = None

    # Strategy 1: article:published_time meta tag (most common, Open Graph)
    pt = soup.find("meta", property="article:published_time")
    if pt and pt.get("content"):
        published = _parse_iso_date(pt["content"])

    # Strategy 2: alternative meta date tags
    if not published:
        for attr_name in ["publish_date", "pubdate", "date", "DC.date.issued", "dcterms.created"]:
            m = soup.find("meta", attrs={"name": attr_name})
            if m and m.get("content"):
                published = _parse_iso_date(m["content"])
                if published:
                    break

    # Strategy 3: itemprop datePublished
    if not published:
        ip = soup.find(attrs={"itemprop": "datePublished"})
        if ip:
            content = ip.get("content") or ip.get("datetime") or ip.get_text(strip=True)
            published = _parse_iso_date(content)

    # Strategy 4: <time datetime="...">
    if not published:
        for t in soup.find_all("time"):
            dt_attr = t.get("datetime")
            if dt_attr:
                published = _parse_iso_date(dt_attr)
                if published:
                    break

    # Strategy 5: JSON-LD structured data (used by many corporate sites)
    if not published:
        published = _extract_jsonld_date(soup)

    # Strategy 6: fall back to body text — look for "May 12, 2026" etc near top
    if not published:
        body_text = soup.get_text(" ", strip=True)[:3000]  # first 3000 chars
        published = _extract_date_from_text(body_text)

    return {"title": title, "description": desc, "published_at": published}


def _parse_iso_date(s: str) -> Optional[datetime]:
    """Parse an ISO-like date string into a UTC datetime, or None."""
    if not s:
        return None
    s = s.strip()
    try:
        # Handle "Z" timezone marker
        d = datetime.fromisoformat(s.replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return d
    except ValueError:
        pass
    # Try date-only (YYYY-MM-DD)
    try:
        return datetime.strptime(s[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _extract_jsonld_date(soup) -> Optional[datetime]:
    """Pull datePublished out of any <script type='application/ld+json'> block."""
    import json
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        if not script.string:
            continue
        try:
            data = json.loads(script.string)
        except (json.JSONDecodeError, TypeError):
            continue
        # data may be dict or list of dicts; walk it
        candidates = data if isinstance(data, list) else [data]
        for item in candidates:
            if not isinstance(item, dict):
                continue
            for key in ("datePublished", "dateCreated", "uploadDate"):
                if key in item:
                    d = _parse_iso_date(str(item[key]))
                    if d:
                        return d
    return None


def _extract_date_from_text(text: str) -> Optional[datetime]:
    """Last-ditch: look for 'May 12, 2026' or similar in article body text."""
    months = {
        "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
        "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
        "jan": 1, "feb": 2, "mar": 3, "apr": 4, "jun": 6, "jul": 7, "aug": 8,
        "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12,
    }
    # Pattern: "May 12, 2026" or "12 May 2026"
    pattern1 = re.compile(r"\b([A-Z][a-z]{2,9})\s+(\d{1,2}),?\s+(\d{4})\b")
    pattern2 = re.compile(r"\b(\d{1,2})\s+([A-Z][a-z]{2,9})\s+(\d{4})\b")
    for pattern, order in [(pattern1, "mdy"), (pattern2, "dmy")]:
        match = pattern.search(text)
        if match:
            try:
                if order == "mdy":
                    month_name, day, year = match.group(1), match.group(2), match.group(3)
                else:
                    day, month_name, year = match.group(1), match.group(2), match.group(3)
                month = months.get(month_name.lower())
                if month:
                    return datetime(int(year), month, int(day), 12, 0, 0, tzinfo=timezone.utc)
            except (ValueError, KeyError):
                continue
    return None


async def scrape_via_sitemap(
    competitor: str,
    sitemap_url: str,
    article_pattern: re.Pattern,
    source_name: str,
    cutoff: datetime,
    client: httpx.AsyncClient,
    upper: Optional[datetime] = None,
) -> list:
    """Generic sitemap-based scraper. Works for SPA newsrooms because sitemaps
    are server-rendered XML, not JavaScript."""
    xml = await fetch_text(sitemap_url, client)
    if not xml:
        return []

    # If it's a sitemap index, follow nested sitemaps (limit to 3 to avoid runaway)
    child_sitemaps = parse_sitemap_index(xml)
    all_urls = []
    if child_sitemaps:
        for child_url in child_sitemaps[:5]:
            child_xml = await fetch_text(child_url, client)
            if child_xml:
                all_urls.extend(parse_sitemap_xml(child_xml, article_pattern, cutoff, upper))
    else:
        all_urls = parse_sitemap_xml(xml, article_pattern, cutoff, upper)

    # Sort by lastmod desc, take top N
    all_urls.sort(key=lambda x: x[1], reverse=True)
    all_urls = all_urls[:MAX_ARTICLES_PER_SOURCE]

    # Fetch article metadata for top results (in parallel)
    articles = []
    metadata_tasks = [fetch_article_metadata(url, client) for url, _ in all_urls[:ARTICLE_FETCH_LIMIT]]
    metadatas = await asyncio.gather(*metadata_tasks, return_exceptions=True)

    skipped_no_date = 0
    skipped_out_of_range = 0

    for (url, lastmod), meta in zip(all_urls[:ARTICLE_FETCH_LIMIT], metadatas):
        if isinstance(meta, Exception) or not meta:
            slug = url.rstrip("/").rsplit("/", 1)[-1].replace(".html", "").replace("-", " ").title()
            title = slug
            desc = slug
            article_date = None
        else:
            title = meta.get("title", "") or url.rsplit("/", 1)[-1]
            desc = meta.get("description", "") or title
            article_date = meta.get("published_at")

        if not title or len(title) < 15:
            continue

        # STRICT filtering: use real publish date if available, else fall back to lastmod
        # If we couldn't determine a real publish date AND the lastmod is in range,
        # we still include it (don't have a better option), but the date in the draft
        # is the lastmod (least bad choice).
        effective_date = article_date or lastmod

        if effective_date < cutoff or (upper is not None and effective_date > upper):
            skipped_out_of_range += 1
            log.debug(
                f"  skip out-of-range: {competitor} {url} "
                f"(real={article_date.date() if article_date else 'unknown'}, "
                f"lastmod={lastmod.date()}, range={cutoff.date()}..{upper.date() if upper else 'now'})"
            )
            continue

        suggestion = suggest_classification(title, desc)
        articles.append(ScrapedArticle(
            competitor=competitor,
            url=url,
            headline=title[:300],
            description=desc[:500] if desc else title[:300],
            published_at=effective_date,
            source=source_name,
            source_priority=1,
            suggested_tag=suggestion["tag"],
            suggested_topics=suggestion["topics"],
            suggested_impact=suggestion["impact"],
        ))

    if skipped_out_of_range:
        log.info(f"  {competitor}: filtered out {skipped_out_of_range} articles whose real publish date was out of range")
    return articles


# ─── PER-COMPETITOR SCRAPERS ─────────────────────────────────────────────────

async def scrape_accenture(client: httpx.AsyncClient, cutoff: datetime, upper: Optional[datetime] = None) -> list:
    pattern = re.compile(r"newsroom\.accenture\.com/news/\d{4}/")
    return await scrape_via_sitemap("Accenture", "https://newsroom.accenture.com/sitemap.xml", pattern, "Accenture Newsroom", cutoff, client, upper)


async def scrape_tcs(client: httpx.AsyncClient, cutoff: datetime, upper: Optional[datetime] = None) -> list:
    pattern = re.compile(r"/who-we-are/newsroom/press-release/")
    results = await scrape_via_sitemap("TCS", "https://www.tcs.com/sitemap.xml", pattern, "TCS Newsroom", cutoff, client, upper)
    if results:
        return results
    return await _scrape_tcs_html(client, cutoff)


async def _scrape_tcs_html(client: httpx.AsyncClient, cutoff: datetime) -> list:
    """Original TCS HTML scraper as fallback."""
    url = "https://www.tcs.com/who-we-are/newsroom"
    html = await fetch_text(url, client)
    if not html:
        return []
    soup = BeautifulSoup(html, "html.parser")
    articles = []
    for link in soup.find_all("a", href=True):
        href = link["href"]
        if "/newsroom/press-release/" not in href:
            continue
        full_url = urljoin(url, href)
        title = link.get_text(strip=True)
        if not title or len(title) < 20:
            continue
        published = datetime.now(timezone.utc)
        if published < cutoff:
            continue
        suggestion = suggest_classification(title, "")
        articles.append(ScrapedArticle(
            competitor="TCS", url=full_url,
            headline=title[:300], description=title[:500],
            published_at=published, source="TCS Newsroom", source_priority=1,
            suggested_tag=suggestion["tag"], suggested_topics=suggestion["topics"], suggested_impact=suggestion["impact"],
        ))
        if len(articles) >= MAX_ARTICLES_PER_SOURCE:
            break
    return articles


async def scrape_infosys(client: httpx.AsyncClient, cutoff: datetime, upper: Optional[datetime] = None) -> list:
    pattern = re.compile(r"/newsroom/press-releases/\d{4}/[^/]+\.html")
    return await scrape_via_sitemap("Infosys", "https://www.infosys.com/sitemap.xml", pattern, "Infosys Newsroom", cutoff, client, upper)


async def scrape_wipro(client: httpx.AsyncClient, cutoff: datetime, upper: Optional[datetime] = None) -> list:
    pattern = re.compile(r"/newsroom/press-releases/\d{4}/")
    return await scrape_via_sitemap("Wipro", "https://www.wipro.com/sitemap.xml", pattern, "Wipro Newsroom", cutoff, client, upper)


async def scrape_capgemini(client: httpx.AsyncClient, cutoff: datetime, upper: Optional[datetime] = None) -> list:
    pattern = re.compile(r"/news/press-releases/")
    return await scrape_via_sitemap("Capgemini", "https://www.capgemini.com/sitemap.xml", pattern, "Capgemini Newsroom", cutoff, client, upper)


# ─── ORCHESTRATOR ────────────────────────────────────────────────────────────

SCRAPERS = {
    "Accenture": scrape_accenture,
    "TCS": scrape_tcs,
    "Infosys": scrape_infosys,
    "Wipro": scrape_wipro,
    "Capgemini": scrape_capgemini,
}


async def scrape_all(
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    days_window: int = 14,
) -> ScrapeResult:
    """Scrape all 5 competitor newsrooms concurrently.

    from_date: lower bound (inclusive); defaults to today - days_window
    to_date:   upper bound (inclusive); defaults to None (no upper bound)
    """
    start = datetime.now(timezone.utc)
    if from_date:
        cutoff = from_date if from_date.tzinfo else from_date.replace(tzinfo=timezone.utc)
    else:
        cutoff = datetime.now(timezone.utc) - timedelta(days=days_window)
    upper = to_date if (to_date is None or to_date.tzinfo) else (to_date.replace(tzinfo=timezone.utc) if to_date else None)

    log.info(f"Scrape range: {cutoff.isoformat()} → {(upper or 'now').isoformat() if upper else 'now'}")

    headers = {"User-Agent": USER_AGENT}
    async with httpx.AsyncClient(timeout=REQUEST_TIMEOUT, headers=headers) as client:
        tasks = {name: asyncio.create_task(s(client, cutoff, upper)) for name, s in SCRAPERS.items()}

        all_articles = []
        failed = []
        for name, task in tasks.items():
            try:
                articles = await task
                all_articles.extend(articles)
                log.info(f"  {name}: {len(articles)} articles")
            except Exception as e:
                log.error(f"  {name} scrape FAILED: {e}")
                failed.append({"source": name, "error": str(e)[:200]})

    duration = (datetime.now(timezone.utc) - start).total_seconds()
    return ScrapeResult(articles=all_articles, failed_sources=failed, duration_seconds=duration)
