"""
api.py — REST API endpoints

Namespaces:
  /api/signals          — PUBLIC, read-only (mobile app + web frontend hit these)
                          Only returns published signals; drafts are hidden.
  /api/admin/signals    — ADMIN, requires login (admin panel hits these)
                          Manages published signals (create, edit, delete).
  /api/admin/drafts     — ADMIN, requires login
                          Manages draft signals from scraper (publish, edit, discard).
  /api/admin/scrape     — ADMIN, requires login
                          Triggers scraping of all 5 competitor newsrooms.
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import Optional
from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field
from sqlmodel import select

from database import get_session
from models import Signal, SignalStatus
from auth import require_admin
from scraper import scrape_all

log = logging.getLogger(__name__)


# ═════════════════════════════════════════════════════════════════════════════
# PUBLIC API — only PUBLISHED signals visible
# ═════════════════════════════════════════════════════════════════════════════

public_router = APIRouter(prefix="/api", tags=["public"])


@public_router.get("/signals")
def list_signals(
    days: int = Query(30, ge=1, le=365),
    competitor: Optional[str] = Query(None),
    topic: Optional[str] = Query(None),
    tag: Optional[str] = Query(None),
    impact: Optional[str] = Query(None),
):
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    with get_session() as s:
        query = (
            select(Signal)
            .where(Signal.status == SignalStatus.PUBLISHED)
            .where(Signal.published_at >= cutoff)
        )
        if competitor:
            query = query.where(Signal.competitor == competitor)
        if impact:
            query = query.where(Signal.impact == impact)
        query = query.order_by(Signal.published_at.desc())
        results = s.exec(query).all()
    if topic:
        results = [r for r in results if topic in r.topics]
    if tag:
        results = [r for r in results if tag in r.tags]
    return results


@public_router.get("/signals/{signal_id}")
def get_signal(signal_id: int):
    with get_session() as s:
        signal = s.exec(
            select(Signal)
            .where(Signal.id == signal_id)
            .where(Signal.status == SignalStatus.PUBLISHED)
        ).first()
        if not signal:
            raise HTTPException(status_code=404, detail="Signal not found")
        return signal


@public_router.get("/health")
def health():
    with get_session() as s:
        pub = len(s.exec(select(Signal).where(Signal.status == SignalStatus.PUBLISHED)).all())
        drf = len(s.exec(select(Signal).where(Signal.status == SignalStatus.DRAFT)).all())
    return {
        "status": "healthy",
        "service": "competitor-pulse",
        "version": "0.3.0-scraper",
        "published_count": pub,
        "draft_count": drf,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


# ═════════════════════════════════════════════════════════════════════════════
# ADMIN API — signals CRUD
# ═════════════════════════════════════════════════════════════════════════════

admin_router = APIRouter(prefix="/api/admin", tags=["admin"])


class SignalIn(BaseModel):
    competitor: str
    headline: str
    description: str
    url: str
    tags: list[str] = Field(default_factory=list)
    topics: list[str] = Field(default_factory=list)
    impact: str = "med"
    source: str
    source_type: str = "official"
    source_priority: int = 1
    published_at: datetime
    impact_pipeline_risk: Optional[str] = None
    impact_verticals: Optional[str] = None
    impact_opportunity: Optional[str] = None
    impact_intel_gap: Optional[str] = None
    analyst_name: Optional[str] = None
    status: str = SignalStatus.PUBLISHED


@admin_router.post("/signals", status_code=201)
def create_signal(payload: SignalIn, admin: str = Depends(require_admin)):
    signal = Signal(
        status=payload.status,
        competitor=payload.competitor,
        headline=payload.headline,
        description=payload.description,
        url=payload.url,
        tags=payload.tags,
        topics=payload.topics,
        impact=payload.impact,
        source=payload.source,
        source_type=payload.source_type,
        source_priority=payload.source_priority,
        published_at=payload.published_at,
        impact_pipeline_risk=payload.impact_pipeline_risk,
        impact_verticals=payload.impact_verticals,
        impact_opportunity=payload.impact_opportunity,
        impact_intel_gap=payload.impact_intel_gap,
        analyst_name=payload.analyst_name or admin,
    )
    with get_session() as s:
        s.add(signal)
        s.commit()
        s.refresh(signal)
    log.info(f"Admin {admin} created {signal.status} signal {signal.id}: {signal.headline[:60]}")
    return signal


@admin_router.put("/signals/{signal_id}")
def update_signal(signal_id: int, payload: SignalIn, admin: str = Depends(require_admin)):
    with get_session() as s:
        signal = s.exec(select(Signal).where(Signal.id == signal_id)).first()
        if not signal:
            raise HTTPException(status_code=404, detail="Signal not found")
        for field, value in payload.model_dump().items():
            setattr(signal, field, value)
        signal.updated_at = datetime.now(timezone.utc)
        s.add(signal)
        s.commit()
        s.refresh(signal)
    log.info(f"Admin {admin} updated signal {signal_id}")
    return signal


@admin_router.delete("/signals/{signal_id}")
def delete_signal(signal_id: int, admin: str = Depends(require_admin)):
    with get_session() as s:
        signal = s.exec(select(Signal).where(Signal.id == signal_id)).first()
        if not signal:
            raise HTTPException(status_code=404, detail="Signal not found")
        s.delete(signal)
        s.commit()
    log.info(f"Admin {admin} deleted signal {signal_id}")
    return {"deleted": signal_id}


@admin_router.get("/signals")
def list_all_signals(admin: str = Depends(require_admin)):
    """List PUBLISHED signals only — drafts visible via /drafts."""
    with get_session() as s:
        return s.exec(
            select(Signal)
            .where(Signal.status == SignalStatus.PUBLISHED)
            .order_by(Signal.published_at.desc())
        ).all()


# ═════════════════════════════════════════════════════════════════════════════
# DRAFTS — pre-filled by scraper, await analyst review
# ═════════════════════════════════════════════════════════════════════════════

@admin_router.get("/drafts")
def list_drafts(admin: str = Depends(require_admin)):
    with get_session() as s:
        return s.exec(
            select(Signal)
            .where(Signal.status == SignalStatus.DRAFT)
            .order_by(Signal.published_at.desc())
        ).all()


@admin_router.post("/drafts/{signal_id}/publish")
def publish_draft(signal_id: int, payload: SignalIn, admin: str = Depends(require_admin)):
    """Convert a draft to published with analyst's added impact analysis."""
    with get_session() as s:
        signal = s.exec(
            select(Signal).where(Signal.id == signal_id).where(Signal.status == SignalStatus.DRAFT)
        ).first()
        if not signal:
            raise HTTPException(status_code=404, detail="Draft not found")
        for field, value in payload.model_dump().items():
            setattr(signal, field, value)
        signal.status = SignalStatus.PUBLISHED
        signal.updated_at = datetime.now(timezone.utc)
        if not signal.analyst_name:
            signal.analyst_name = admin
        s.add(signal)
        s.commit()
        s.refresh(signal)
    log.info(f"Admin {admin} published draft {signal_id}: {signal.headline[:60]}")
    return signal


# ═════════════════════════════════════════════════════════════════════════════
# SCRAPER — fetches new articles from 5 P1 newsrooms
# ═════════════════════════════════════════════════════════════════════════════

@admin_router.post("/scrape")
async def trigger_scrape(
    days: int = Query(14, ge=1, le=180),
    from_date: Optional[str] = Query(None, description="ISO date — articles published on or after this date"),
    to_date: Optional[str] = Query(None, description="ISO date — articles published on or before this date"),
    admin: str = Depends(require_admin),
):
    """Scrape 5 competitor newsrooms; create drafts for new articles.

    Date filtering precedence:
      - If from_date AND to_date supplied: only articles in [from_date, to_date]
      - If only from_date: articles from from_date onwards (no upper bound)
      - If neither: last `days` days
    Returns full details of duplicates so analyst can review and discard.
    """
    log.info(f"Admin {admin} triggered scrape (days={days}, from={from_date}, to={to_date})")

    parsed_from = None
    parsed_to = None
    if from_date:
        try:
            parsed_from = datetime.fromisoformat(from_date).replace(tzinfo=timezone.utc)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid from_date format. Use YYYY-MM-DD.")
    if to_date:
        try:
            # Interpret to_date as end-of-day (inclusive)
            parsed_to = datetime.fromisoformat(to_date).replace(hour=23, minute=59, second=59, tzinfo=timezone.utc)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid to_date format. Use YYYY-MM-DD.")
    if parsed_from and parsed_to and parsed_from > parsed_to:
        raise HTTPException(status_code=400, detail="from_date must be on or before to_date.")

    result = await scrape_all(from_date=parsed_from, to_date=parsed_to, days_window=days)

    new_drafts = 0
    duplicates = []
    errors = 0

    with get_session() as s:
        for article in result.articles:
            existing = s.exec(select(Signal).where(Signal.url == article.url)).first()
            if existing:
                duplicates.append({
                    "scraped_headline": article.headline,
                    "scraped_url": article.url,
                    "scraped_competitor": article.competitor,
                    "scraped_published_at": article.published_at.isoformat(),
                    "existing_id": existing.id,
                    "existing_status": existing.status,
                    "existing_headline": existing.headline,
                })
                continue
            try:
                signal = Signal(
                    status=SignalStatus.DRAFT,
                    competitor=article.competitor,
                    headline=article.headline,
                    description=article.description,
                    url=article.url,
                    tags=[article.suggested_tag] if article.suggested_tag else [],
                    topics=article.suggested_topics or [],
                    impact=article.suggested_impact,
                    source=article.source,
                    source_type="official",
                    source_priority=article.source_priority,
                    published_at=article.published_at,
                )
                s.add(signal)
                new_drafts += 1
            except Exception as e:
                log.warning(f"Could not save article {article.url}: {e}")
                errors += 1
        s.commit()

    log.info(
        f"Scrape: {new_drafts} new drafts, {len(duplicates)} duplicates, "
        f"{errors} errors, {len(result.failed_sources)} sources failed"
    )

    return {
        "new_drafts": new_drafts,
        "duplicates_skipped": len(duplicates),
        "duplicates": duplicates,
        "errors": errors,
        "failed_sources": result.failed_sources,
        "duration_seconds": round(result.duration_seconds, 1),
        "total_articles_found": len(result.articles),
        "date_range_used": {
            "from": (parsed_from or (datetime.now(timezone.utc) - timedelta(days=days))).isoformat(),
            "to": (parsed_to or datetime.now(timezone.utc)).isoformat(),
        },
    }
